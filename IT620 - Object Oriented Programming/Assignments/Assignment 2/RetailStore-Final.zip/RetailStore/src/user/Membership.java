package user;


public enum Membership {
    NOT_A_MEMBER,
    IS_MEMBER,
}
