package products;

public enum Availability {
    IN_STORE,
    OUT_OF_STOCK,
}