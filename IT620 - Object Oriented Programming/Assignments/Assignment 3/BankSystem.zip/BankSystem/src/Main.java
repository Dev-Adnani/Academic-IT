import account.Account;
import account.AccountType;
import accountHelper.AccountHelper;
import admin.Admin;
import adminHelper.AdminHelper;

import java.util.HashMap;

import static java.lang.System.exit;
import static utils.Utils.*;

public class Main {
    //Note  : Please Compile And Run Code In Terminal As We Have Used Console (For Password) , Which Only Works In Terminal
    public static void main(String[] args) {

        boolean isRegistered = false, isLoggedIn = false;
        AccountHelper accountHelper = new AccountHelper();
        HashMap<String, Account> users = new HashMap<>();
        AdminHelper adminHelper = new AdminHelper();
        Account loggedUser = null;
        int choice;

        while (true) {
            while (!isLoggedIn || !isRegistered) {
                print("Enter 1 For Registering");
                print("Enter 2 For Login");
                print("Enter 3 For Admin Access");
                print("Enter 4 For Forget Password");
                print("Enter 5 For Clearing Screen");
                print("Enter 6 For Closing The App");


                try {
                    choice = userInputInt("Enter Your Choice");

                    switch (choice) {
                        case 1: {
                            isRegistered = accountHelper.registerUser(users);
                            if (!isRegistered) {
                                print("Username Already Exists");
                            }
                            break;
                        }
                        case 2: {
                            if (isRegistered) {
                                loggedUser = accountHelper.loginUser(users);
                                if (loggedUser == null) {
                                    print("Wrong username or Password");
                                } else {
                                    isLoggedIn = true;
                                }
                            } else {
                                print("Please Register Before Trying To Login");
                            }
                            break;
                        }
                        case 3: {
                            adminHelper.showAdminMenu(users);
                        }
                        case 4: {
                            if (isRegistered) {
                                boolean passChangeStatus = accountHelper.forgetPassword(users);
                                if (passChangeStatus) {
                                    print("Password Changed Successfully");
                                } else {
                                    print("Oops Wrong Username");
                                }
                            } else {
                                print("You Must Register Before , If You Wanna Change Password");
                            }
                            break;
                        }
                        case 5: {
                            clearTerminal();
                            break;
                        }
                        case 6: {
                            print("Bye Bye");
                            exit(1);
                            break;
                        }
                        default:
                            print("Wrong Choice...");
                            break;

                    }
                } catch (NumberFormatException e) {
                    print("Invalid Input! Please enter a valid number.");
                } catch (Exception e) {
                    print("An error occurred: " + e.getMessage());
                }
            }

            while (true) {
                print("Enter 1 For User Profile");
                print("Enter 2 For Deposit");
                print("Enter 3 For Withdrawal");
                print("Enter 4 For Loan");
                print("Enter 5 For Transferring ");
                print("Enter 6 For Logout");
                print("Enter 7 For Closing The App");
                print("Enter 8 For Clearing Screen");

                try {
                    choice = userInputInt("Enter Your Choice");

                    switch (choice) {
                        case 1:
                            accountHelper.displayUserProfile(loggedUser);
                            break;
                        case 2: {
                            double enterAmount = userInputDouble("Enter Amount To Deposit : ");
                            int noOfYears = userInputInt("Enter Number Of Years :");
                            if (enterAmount <= 0 || noOfYears < 0) {
                                print("Invalid choice");
                                return;
                            } else {
                                loggedUser.depositAmountUser(enterAmount, noOfYears);
                                print("Deposit successfully!");
                            }
                            break;
                        }
                        case 3: {
                            double withdrawalAmt = userInputDouble("Enter the amount you want to withdraw :");
                            boolean withdrawalDone = loggedUser.withdrawAmountUser(withdrawalAmt);
                            if (withdrawalDone)
                                print("Withdraw successful!");
                            else {
                                print("Please check the amount");
                                print("Note : The Minimum Balance Should Be" + loggedUser.getMinimumBalance());
                            }
                            break;
                        }
                        case 4: {
                            double loanAmt = userInputDouble("Enter Amount For Loan");
                            if (loggedUser.getAccountType() == AccountType.SAVINGS_ACCOUNT)
                                loggedUser.approveOnSavings(loanAmt);
                            else
                                loggedUser.approveOnCurrent(loanAmt);
                            break;
                        }
                        case 5:
                        {
                            String dest = userInputString("Username of dest account");
                            double amt = userInputDouble("Enter The Amount To Be Transferred : ");

                            if (dest.isEmpty()) {
                                throw new Exception("Please Enter Username");
                            }  else if (!users.containsKey(dest)) {
                                throw new Exception("Destination user doesn't exist");
                            } else {
                                Account destAccount = users.get(dest);
                                boolean transferred = new Admin().transfer(loggedUser,destAccount,amt);
                                if(transferred)
                                    print("Amount Transferred Successfully");
                                else
                                    print("Oops Some Error Occurred");
                            }
                        }
                        break;
                        case 6:
                            print("Processing.");
                            print("Processing.....");
                            print("Processing.......");
                            print("Processing.........");
                            print("Processing...........");
                            break;
                        case 7:
                            print("Bye Bye");
                            exit(1);
                            break;
                        case 8:
                            clearTerminal();
                            break;
                        default:
                            print("Enter Valid Choice");
                            break;
                    }

                    if (choice == 6) {
                        print("Good Bye , Hope You Had A Good Time");
                        loggedUser = null;
                        isLoggedIn = false;
                        clearTerminal();
                        break;
                    }
                } catch (NumberFormatException e) {
                    print("Invalid Input! Please enter a valid number.");
                } catch (Exception e) {
                    print("An error occurred: " + e.getMessage());
                }
            }
        }
    }
}
