package accountHelper;

import account.Account;
import account.CurrentAccount;
import account.SavingsAccount;

import java.util.HashMap;

import static utils.Utils.*;

public class AccountHelper {
    public Account createAccount(String accountType, String fullName, String userName) {
        if (accountType.equalsIgnoreCase("savings")) {
            return new SavingsAccount(fullName, userName);
        } else {
            return new CurrentAccount(fullName, userName);
        }
    }

    //Forget Password - Just Checking If Name Is Same As Old Or Not , If Yes We Change The Password , Else We Return False
    public boolean forgetPassword(HashMap<String, Account> users) {
        String userName, password;
        userName = userInputString("Username");
        password = hashedPassword();

        boolean userNameCheck = users.containsKey(userName);

        if (userNameCheck) {
            users.get(userName).setPassword(password);
            return true;
        } else {
            return false;
        }
    }

    public boolean registerUser(HashMap<String, Account> users) {
        String userName, password, fullName, isMember;
        boolean isRegistered = false;
        try {
            fullName = userInputString("Full name");
            userName = userInputString("Username");
            isMember = userInputString("Yes For Savings Account ,No For Current Account : ");
            password = hashedPassword();

            if (fullName.isEmpty() || userName.isEmpty() || isMember.isEmpty() || password.isEmpty()) {
                print("Please Enter Some Data !xD");
            } else {
                //Checking If Username Already Exists - Not Permitting Multiple Users With Same Username
                boolean allowUser = users.containsKey(userName);
                if (!allowUser) {
                    Account account = createAccount(isMember.equalsIgnoreCase("yes") ? "savings" : "current", fullName, userName);
                    account.setPassword(password);
                    users.put(userName, account);
                    isRegistered = true;
                }
            }
        } catch (Exception e) {
            print("An error occurred while registering user: " + e.getMessage());
        }
        return isRegistered;
    }

    public Account loginUser(HashMap<String, Account> users) {
        String userName, password;
        Account loggedUser = null;
        try {
            userName = userInputString("Username");
            boolean userNameCheck = users.containsKey(userName);
            if (userNameCheck) {
                password = hashedPassword();
                String userPass = users.get(userName).getPassword();
                if (userPass.equals(password)) {
                    loggedUser = users.get(userName);
                }
            }
        } catch (Exception e) {
            print("An error occurred while logging in: " + e.getMessage());
        }
        return loggedUser;
    }

    public void displayUserProfile(Account user) {
        try {
            print("--------------------------- USER PROFILE-------------------------------- ");
            print("Account Number : " + user.getAccountNumber());
            print("Full Name      : " + user.getFullName());
            print("Username       : " + user.getUsername());
            print("Balance        : " + user.getBalance());
            print("Account Type   : " + user.getAccountType());
            print("Interest Rate  : " + user.getInterestRate() + "%");
            print("----------------------END OF USER PROFILE-------------------------------- ");
        } catch (Exception e) {
            print("An error occurred while displaying user profile: " + e.getMessage());
        }
    }
}