package admin;

import account.Account;

import java.util.HashMap;

public interface AdminInterface {
    public void checkAllAccounts(HashMap<String, Account> users);

    public void getDataOfUserAccount(Account account);

    public void writeDataToFile(HashMap<String, Account> users);
}
