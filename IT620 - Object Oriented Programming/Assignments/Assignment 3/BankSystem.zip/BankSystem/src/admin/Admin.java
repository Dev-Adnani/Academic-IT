package admin;


import account.Account;
import accountHelper.AccountHelper;
import bankOperations.Transferable;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static utils.Utils.print;

public class Admin implements AdminInterface, Transferable {

    AccountHelper accountHelper = new AccountHelper();

    @Override
    public void checkAllAccounts(HashMap<String, Account> users) {
        for (Account account : users.values()) {
            accountHelper.displayUserProfile(account);
        }
    }

    @Override
    public void getDataOfUserAccount(Account account) {
        accountHelper.displayUserProfile(account);
    }

    @Override
    public void writeDataToFile(HashMap<String, Account> users) {
        ExecutorService executor = Executors.newFixedThreadPool(2);

        // write the contents of the HashMap to a file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"))) {
            for (Map.Entry<String, Account> entry : users.entrySet()) {
                // submit a task to the executor to write the entry to the file
                executor.submit(() -> {
                    try {
                        writer.write(entry.getKey() + "=" + entry.getValue().toString() + "\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            }
            // wait for all tasks to complete
            executor.shutdown();
            executor.awaitTermination(Long.MAX_VALUE, java.util.concurrent.TimeUnit.NANOSECONDS);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean transfer(Account sourceAccount, Account destAccount, double amount) {
        if (sourceAccount.getBalance() >= amount) {
            sourceAccount.withdraw(amount);
            destAccount.deposit(amount);
            return true;
        } else {
            return false;
        }
    }
}
