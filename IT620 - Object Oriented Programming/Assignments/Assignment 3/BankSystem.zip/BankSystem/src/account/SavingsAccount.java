package account;

public class SavingsAccount extends Account {
    public SavingsAccount(String fullName, String userName) {
        super(fullName, userName);
        setAccountType(AccountType.SAVINGS_ACCOUNT);
        setInterestRate(7);
        setMinimumBalance(1000);
    }

    @Override
    public void approveOnSavings(double loanAmt) {
        double balance = getBalance();
        if (balance >= 100000) {
            if (loanAmt > 0 && loanAmt <= balance * 1.5) {
                System.out.println("Your Loan is Approved!");
            } else {
                System.out.println("Your request has been noted. Your branch will contact you for followup!");
            }
        } else {
            System.out.println("Your request has been noted. Your branch will contact you for followup!");
        }
    }

}
