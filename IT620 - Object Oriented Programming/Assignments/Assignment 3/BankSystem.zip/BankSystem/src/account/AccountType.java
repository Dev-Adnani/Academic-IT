package account;

public enum AccountType {
    SAVINGS_ACCOUNT, CURRENT_ACCOUNT
}
