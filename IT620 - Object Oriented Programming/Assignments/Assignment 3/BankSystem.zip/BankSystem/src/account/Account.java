package account;

import bankOperations.ApproveLoan;
import bankOperations.CalculateInterest;

import static utils.Utils.*;

public class Account implements CalculateInterest, ApproveLoan {
    private static int lastAccountNo = 0;
    private String username, password, fullName;
    private double balance = 0;
    private int accountNumber;
    private double minimumBalance;
    private AccountType accountType;
    private double interestRate;

    // Constructor
    public Account(String username, String fullName) {
        this.username = username;
        this.fullName = fullName;
        this.accountNumber = ++lastAccountNo;
    }

    public void interest(double amount, int years) {
        double interestAmount = (amount * years * interestRate) / 100;
        System.out.println("You will get an interest of " + interestAmount + " each year !");
    }

    //Get Account Type
    public AccountType getAccountType() {
        return accountType;
    }

    //Set Account Type
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    //Get Interest Rate
    public double getInterestRate() {
        return interestRate;
    }

    //Set Interest Rate
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    // Get - FullName
    public String getFullName() {
        return fullName;
    }

    // Set - FullName
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    //Get - UserName
    public String getUsername() {
        return username;
    }

    // Set Username
    public void setUsername(String username) {
        this.username = username;
    }

    // Get - Password
    public String getPassword() {
        return password;
    }

    // Set - Password
    public void setPassword(String password) {
        this.password = password;
    }

    // Get User ID
    public int getAccountNumber() {
        return accountNumber;
    }

    // Get Balance
    public double getBalance() {
        return balance;
    }

    // Set Balance
    public void setBalance(double balance) {
        this.balance = balance;
    }

    //Get MinimumBalance
    public double getMinimumBalance() {
        return minimumBalance;
    }

    //Set MinimumBalance
    public void setMinimumBalance(double minimumBalance) {
        this.minimumBalance = minimumBalance;
    }


    //Withdrawal From User
    public boolean withdrawAmountUser(double withdrawalAmt) {
        if (withdrawalAmt <= 0 ||withdrawalAmt > balance  || balance - getMinimumBalance() < withdrawalAmt) {
            return false;
        }
        else {
            setBalance(getBalance() - withdrawalAmt);
            return true;
        }
    }

    //Deposit Amount From User
    public void depositAmountUser(double enterAmount,int noOfYears) {
        setBalance(getBalance() + enterAmount);
        interest(getBalance(), noOfYears);
    }


    public void deposit(double amount) {
        setBalance(getBalance() + amount);
    }

    // Withdraw method
    public void withdraw(double amount) {
        if (balance >= amount) balance -= amount;

    }



    @Override
    public void approveOnSavings(double loanAmt) {

    }

    @Override
    public void approveOnCurrent(double loanAmt) {

    }

    @Override
    public String toString() {
        return "Account{" +
                "username='" + username + '\'' +
                ", fullName='" + fullName + '\'' +
                ", password='" + password + '\'' +
                ", balance=" + balance +
                ", accountNumber=" + accountNumber +
                ", minimumBalance=" + minimumBalance +
                ", accountType=" + accountType +
                ", interestRate=" + interestRate +
                '}';
    }
}


