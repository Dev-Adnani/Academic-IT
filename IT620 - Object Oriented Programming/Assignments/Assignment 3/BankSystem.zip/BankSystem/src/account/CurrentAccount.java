package account;

public class CurrentAccount extends Account {
    public CurrentAccount(String fullName, String userName) {
        super(fullName, userName);
        setAccountType(AccountType.CURRENT_ACCOUNT);
        setInterestRate(2);
        setMinimumBalance(5000);
    }

    @Override
    public void approveOnCurrent(double loanAmt) {
        double balance = getBalance();
        if (balance >= 500000) {
            if (loanAmt > 0 && loanAmt <= balance * 3) {
                System.out.println("Your Loan is Approved!");
            } else {
                System.out.println("Your request has been noted. Your branch will contact you for followup!");
            }
        } else {
            System.out.println("Your request has been noted. Your branch will contact you for followup!");
        }
    }
}
