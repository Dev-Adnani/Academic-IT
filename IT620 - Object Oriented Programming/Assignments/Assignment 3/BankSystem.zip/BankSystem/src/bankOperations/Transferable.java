package bankOperations;

import account.Account;

public interface Transferable {

    // Transfers the specified amount from the source account to the destination account
    public boolean transfer(Account sourceAccount, Account destAccount, double amount);

}
