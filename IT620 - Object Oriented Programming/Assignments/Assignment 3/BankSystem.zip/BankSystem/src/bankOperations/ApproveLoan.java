package bankOperations;

public interface ApproveLoan {
    void approveOnSavings(double loanAmt);
    void approveOnCurrent(double loanAmt);
}


