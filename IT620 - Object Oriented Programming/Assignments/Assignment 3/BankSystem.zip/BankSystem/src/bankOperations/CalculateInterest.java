package bankOperations;

public interface CalculateInterest {
    private void interest(int amount,int time){
    }
}



