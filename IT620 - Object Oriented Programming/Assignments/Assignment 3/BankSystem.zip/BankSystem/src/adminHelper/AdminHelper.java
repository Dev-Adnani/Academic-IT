package adminHelper;

import account.Account;
import admin.Admin;

import java.util.HashMap;

import static utils.Utils.*;

public class AdminHelper {

    boolean isLogged = false;
    Admin admin = new Admin();

    public void showAdminMenu(HashMap<String, Account> users) {
        while (true) {
            try {
                while (!isLogged) {
                    print("Enter 1 For Login");
                    print("Enter 2 For Exit");
                    int ch = userInputInt("Enter Your Choice :");
                    switch (ch) {
                        case 1 -> {
                            String uname = userInputString("username");
                            String password = hashedPassword();
                            if (uname.equals("admin") && password.equals("daiict")) {
                                isLogged = true;
                            } else {
                                throw new Exception("Invalid username or password");
                            }
                        }
                        case 2 -> {
                            return;
                        }
                        default -> {
                            throw new Exception("Invalid choice, please enter a valid choice");
                        }
                    }
                }
                while (true) {
                    print("Enter 1 For Getting All User List");
                    print("Enter 2 For Getting Detail Of Particular User");
                    print("Enter 3 For Transferring Money Between Users");
                    print("Enter 4 Going Back To Main Screen");
                    print("Enter 5 For Clearing Screen");
                    print("Enter 6 For Generating File of All Account");

                    int ch = userInputInt("Enter Your Choice :");
                    switch (ch) {
                        case 1 -> {
                            admin.checkAllAccounts(users);
                        }
                        case 2 -> {
                            String userName = userInputString("Username");
                            if (userName.isEmpty()) {
                                throw new Exception("Please Enter Username");
                            } else if (!users.containsKey(userName)) {
                                throw new Exception("User doesn't exist");
                            } else {
                                Account account = users.get(userName);
                                admin.getDataOfUserAccount(account);
                            }
                        }
                        case 3 ->
                        {
                            String source = userInputString("Username of source account");
                            String dest = userInputString("Username of dest account");
                            double amt = userInputDouble("Enter The Amount To Be Transferred : ");

                            if (source.isEmpty() || dest.isEmpty()) {
                                throw new Exception("Please Enter Username");
                            } else if (!users.containsKey(source)) {
                                throw new Exception("Source user doesn't exist");
                            } else if (!users.containsKey(dest)) {
                                throw new Exception("Destination user doesn't exist");
                            } else {
                                Account sourceAccount = users.get(source);
                                Account destAccount = users.get(dest);
                                boolean transferred = admin.transfer(sourceAccount,destAccount,amt);
                                if(transferred)
                                    print("Amount Transferred Successfully");
                                else
                                    print("Oops Some Error Occurred");
                            }
                        }
                        case 4 -> {
                            isLogged=true;
                            return;
                        }
                        case 5 -> clearTerminal();
                        default -> {
                            throw new Exception("Invalid choice, please enter a valid choice");
                        }
                        case 6 ->
                        {
                            admin.writeDataToFile(users);
                        }
                    }
                }
            } catch (Exception e) {
                print("Error occurred: Enter Valid Data");
            }
        }
    }
}
