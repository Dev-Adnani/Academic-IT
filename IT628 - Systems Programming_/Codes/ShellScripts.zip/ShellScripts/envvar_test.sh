#!/bin/bash
echo $localvar
echo $envvar

