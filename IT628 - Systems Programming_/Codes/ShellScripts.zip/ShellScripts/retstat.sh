#!/bin/bash 
# Author : Amit

# Get return status and display it

./retstat.out
retval=$?
echo $retval
