extern int true_global;
void f1();