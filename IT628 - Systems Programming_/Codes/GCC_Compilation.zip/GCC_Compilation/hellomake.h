/* example include file */ 
void myPrintHelloMake(void);

int global;


