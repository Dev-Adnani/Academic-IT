#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// get IPv4 addresses
//#define ip_type AF_INET
// get IPv6 addresses
#define ip_type AF_INET6

int main(int argc, char *argv[ ]) 
{
	struct hostent *h;
	char dst[100];
 
	/* error check the command line */
	if(argc != 2)
	{
	fprintf(stderr, "Usage: %s hostname\n", argv[0]);
	exit(1);
	}
	/* get the host info */
	if((h=gethostbyname2(argv[1], ip_type)) == NULL) 
	{
		herror("gethostbyname(): ");
		exit(1);
	}
	else
	{
		printf("Hostname: %s\n", h->h_name);
		for (int i=0; h->h_addr_list[i]!=NULL; i++)
		{
			printf("IP Address %d: %s\n", i+1, inet_ntop(ip_type, (void *)h->h_addr_list[i], dst, 100));
		}
	}
	return 0;
}
