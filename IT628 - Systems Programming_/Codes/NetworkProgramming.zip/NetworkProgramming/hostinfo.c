#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netdb.h>

#define	MAXLINE	 8192  /* Max text line length */
//#define IPv4 1	/* define if need only IPv4 addresses */

int main(int argc, char **argv) 
{
    struct addrinfo *p, *listp, hints;
    char host[MAXLINE],service[MAXLINE];
    int rc, flags;

    if (argc != 2) {
	fprintf(stderr, "usage: %s <domain name>\n", argv[0]);
	exit(0);
    }

    /* Get a list of addrinfo records */
    memset(&hints, 0, sizeof(struct addrinfo));                         
#if IPv4
    hints.ai_family = AF_INET;       /* IPv4 only */        //line:netp:hostinfo:family
#endif
    hints.ai_socktype = SOCK_STREAM; /* Connections only */ //line:netp:hostinfo:socktype
    if ((rc = getaddrinfo(argv[1], "http", &hints, &listp)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(rc));
        exit(1);
    }

    /* Walk the list and display each IP address */
	flags = 0;
    //flags = NI_NUMERICHOST | NI_NUMERICSERV; /* Display address string instead of domain name and port number instead of service name */
	
	
    for (p = listp; p; p = p->ai_next) {
        getnameinfo(p->ai_addr, p->ai_addrlen, host, MAXLINE, service, MAXLINE, flags);
        printf("host:%s, service:%s\n", host, service);
    } 

    /* Clean up */
    freeaddrinfo(listp);

    exit(0);
}

/*
$ ./hostinfo.out www.daiict.ac.in
220.226.182.128

$ ./hostinfo.out localhost
127.0.0.1

$ ./hostinfo.out www.twitter.com
104.244.42.65
104.244.42.1

$ ./hostinfo.out www.google.com
172.217.163.68
2404:6800:4007:809::2004

$ ./hostinfo.out www.facebook.com
157.240.13.35
2a03:2880:f10c:83:face:b00c:0:25de
*/
